﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;
using Microsoft.Win32;
using MySql.Data;
using MySql.Data.MySqlClient;




namespace sbtc
{
    public partial class frmMain : Form
    {

        int pkey = 0;

        public frmMain()
        {
            InitializeComponent();
        }

        private void getSettings()
        {
            string Temp = Application.StartupPath.ToUpper();
            string Temp2 = "";



            int LoopCount = 0;
            while (LoopCount < Temp.Length-5)
            {
                if (Temp.Substring(LoopCount,4) == "AUTO")
                {
                    Temp2 = Temp.Substring(0,LoopCount-1);
                }

                if (Temp.Substring(LoopCount,5) == "CODES")
                {
                    ReturnMe.CodesOnly = true;
                }
            
    
                LoopCount = LoopCount +1;
            }



            LoopCount = 0;

            var fileStream = new FileStream(Temp2 +"\\Auto\\Settings.ini", FileMode.Open, FileAccess.Read);
            using (var streamReader = new StreamReader(fileStream, Encoding.UTF8))
            {
                string line;
                while ((line = streamReader.ReadLine()) != null)
                {
                    LoopCount = LoopCount +1;
                    if (LoopCount == 1) ReturnMe.server = line;
                    if (LoopCount == 2) ReturnMe.Resting_Folder = line;
                    if (LoopCount == 3) ReturnMe.PrinterFiles_Folder = line;
                }
            }
            fileStream.Close();



            LoopCount = 0;
            fileStream = new FileStream("C:\\WinZip.txt", FileMode.Open, FileAccess.Read);
            using (var streamReader = new StreamReader(fileStream, Encoding.UTF8))
            {
                string line;
                while ((line = streamReader.ReadLine()) != null)
                {
                    
                    LoopCount = LoopCount + 1;
                    if (LoopCount == 1) ReturnMe.WinZipLocation = line;

                    
                }
            }
            fileStream.Close();

            
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            
            getSettings();

            dteDeliveryDate.Value = DateTime.Today;

            ListFilesHead();

            ReturnMe.TimeStart = DateTime.Now.ToString("HH:mm");
            ReturnMe.DateTimeToday_date = DateTime.Now;

            CheckHashTotal();
        }



        private void CheckHashTotal()
        {
            string dbase = "";
            if (ReturnMe.CodesOnly == true) dbase = "captive_database.master_database_sbtc_temp";
            if (ReturnMe.CodesOnly == false) dbase = "captive_database.master_database_sbtc";

            string sql = "SELECT DISTINCT(FinalBatch) FROM " + dbase + " WHERE HashSentDate is NULL AND HashSentTime IS NULL";
            string MyConnection2 = "datasource=" + ReturnMe.server + ";port=3306;username=" + ReturnMe.uid + ";password=" + ReturnMe.password;
            MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);
            MySqlCommand MyCommand2 = new MySqlCommand(sql, MyConn2);
            MySqlDataReader MyReader2;
            MyConn2.Open();
            MyReader2 = MyCommand2.ExecuteReader();

            int LoopCount = 0;

            while (MyReader2.Read())
            {
                LoopCount = LoopCount + 1;
                //column_name = MyReader2.GetValue(0).ToString();
                //column_name_orig = MyReader2.GetValue(0).ToString();
            }

            if (LoopCount >= 1)
            {
                lblHashTotal.Visible = true;

                if (LoopCount == 1)
                {
                    lblHashTotal.Text = "1 Hash Total hasn't been sent yet";
                }
                else lblHashTotal.Text = LoopCount.ToString() + " Hash Totals hasn't been sent yet";
                
            }
            else
            {
                lblHashTotal.Visible = false;
            }
        }



        public void ListFilesHead()
        {
            lstFiles.Items.Clear();

            string[] files = Directory.GetFiles(Application.StartupPath+"\\Head\\","*.txt");

            foreach (string file in files)
            {

                string filename = "";

                int LoopCount = file.Length-1;
                while (LoopCount > 4)
                {
                    if (file.Substring(LoopCount, 1) == "\\")
                    {
                        if (filename == "")
                        {
                            filename = file.Substring(LoopCount + 1, file.Length - LoopCount - 1);
                        }
                    }

                    LoopCount = LoopCount - 1;
                }

                lstFiles.Items.Add(filename);
            }


            if (lstFiles.Items.Count == 0)
            {
                btnCheckFiles.Enabled = false;
            }
            else
            {
                btnCheckFiles.Enabled = true;
            }
        }

        private void btnCheckFiles_Click(object sender, EventArgs e)
        {
            btnEncode.Enabled = false;

            if (dteDeliveryDate.Value.ToShortDateString() == DateTime.Today.ToShortDateString())
            {
                DialogResult result3 = MessageBox.Show("Please select Delivery Date", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                dteDeliveryDate.Focus();
                return;
            }




            if (btnCheckFiles.Text == "Check Files on Head")
            {
                DialogResult result1 = MessageBox.Show("Are you sure you want to check " + lstFiles.Items.Count + " items?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (result1 == DialogResult.No)
                {
                    return;
                }


                CreateTable();

                int LoopCount = 0;
                while (LoopCount < lstFiles.Items.Count)
                {
                    string filename = lstFiles.Items[LoopCount].ToString();

                    CheckFiles(filename);

                    LoopCount = LoopCount + 1;
                }


                CheckBranches();









                //Check for Errors
                OleDbConnection conn1 = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Application.StartupPath + ";Extended Properties=dBASE III;");
                OleDbDataAdapter command1 = new OleDbDataAdapter("SELECT Errors FROM Errors", conn1);
                conn1.Open();
                DataSet dataSet = new DataSet();
                command1.Fill(dataSet);

                DataTable dt = dataSet.Tables[0];
                foreach (DataRow dr in dt.Rows)
                {
                    string errors = dr[0].ToString();
                }
                //End Check for Errors





                if (dt.Rows.Count > 0)
                {
                    MessageBox.Show("There are " + dt.Rows.Count + " error/s found. See Errors.txt", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    Application.Exit();
                }
                else
                {
                    DisplayData();


                    btnCheckFiles.Text = "Process ! ! !";


                    //For Sort RT
                    ReturnMe.SortRT("Regular");
                    ReturnMe.SortRT("Regular\\PreEncoded");
                    ReturnMe.SortRT("MC");
                    ReturnMe.SortRT("CheckOne");
                    ReturnMe.SortRT("CheckPower");
                    ReturnMe.SortRT("GiftCheck");
                    //End For Sort RT

                    MessageBox.Show("Data has been Checked. No Errors found!", " ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {

                string Batch = DateTime.Now.ToString("MMddyyyy");
                if (ReturnMe.InputBox("Batch", "Enter Batch Name:", ref Batch) == DialogResult.OK)
                {

                }
                else
                {
                    Batch = "";
                }

                if (Batch == "") { return; }
                

                //Check if Batch exists
                if (Directory.Exists(Application.StartupPath+"\\Archive\\"+Batch))
                {
                    MessageBox.Show("Batch " + Batch + " already exists", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                //End Check if Batch exists


                //For Process By
                string ProcessBy = "";
                if (ReturnMe.InputBox("", "Enter Process By:", ref ProcessBy) == DialogResult.OK)
                {

                }
                else
                {
                    ProcessBy = "";
                }

                if (ProcessBy == "") { return; }


                string CheckedBy = "";
                if (ReturnMe.InputBox("", "Enter Checked By:", ref CheckedBy) == DialogResult.OK)
                {

                }
                else
                {
                    CheckedBy = "";
                }

                if (CheckedBy == "") { return; }
                //End for Process By


                //For Zip
                string DateTimeToday = DateTime.Now.ToString("MMddyyyyHHmmss");

                Directory.CreateDirectory("C:\\Windows\\Temp\\" + DateTimeToday + "\\" + Batch);
                //End For Zip






                //Clear Folder
                int LoopCount = 0;
                while (LoopCount < 10)
                {
                    string FolderLocation = "";
                    if (LoopCount == 0) {FolderLocation = Application.StartupPath + "\\Charge_Slip";}
                    if (LoopCount == 1) {FolderLocation = Application.StartupPath + "\\CheckOne";}
                    if (LoopCount == 2) {FolderLocation = Application.StartupPath + "\\CheckPower";}
                    if (LoopCount == 3) {FolderLocation = Application.StartupPath + "\\Customized";}
                    if (LoopCount == 4) {FolderLocation = Application.StartupPath + "\\GiftCheck";}
                    if (LoopCount == 5) {FolderLocation = Application.StartupPath + "\\MC";}
                    if (LoopCount == 6) {FolderLocation = Application.StartupPath + "\\MC\\Continues";}
                    if (LoopCount == 7) {FolderLocation = Application.StartupPath + "\\Regular";}
                    if (LoopCount == 8) {FolderLocation = Application.StartupPath + "\\Regular\\PreEncoded";}
                    if (LoopCount == 9) 
                    { 
                        FolderLocation = Application.StartupPath;
                    }

                    string[] files = Directory.GetFiles(FolderLocation, "*.*");
                    foreach (string file in files)
                    {
                        if (file.Substring(file.Length - 3, 3).ToUpper() == "TXT")
                        {
                            if (LoopCount >= 0 && LoopCount <= 8)
                            {
                                if (file.Substring(file.Length - 10, 10).ToUpper() != "SORTRT.TXT")
                                {
                                    File.Delete(file);
                                }
                            }
                        }

                        if (file.Substring(file.Length - 3, 3).ToUpper() == "MDB")
                        {
                            if (LoopCount >= 0 && LoopCount <= 8)
                            {
                                File.Delete(file);
                            }
                        }
                        if (file.Substring(file.Length - 3, 3).ToUpper() == "ZIP")
                        {
                            if (LoopCount ==9 )
                            {
                                File.Delete(file);
                            }
                        }
                    }
                    LoopCount = LoopCount + 1;
                }
                //End Clear Folder



                ReturnMe.ProcessAll(Batch,ProcessBy, CheckedBy, dteDeliveryDate.Value,DateTimeToday);


                TransferAll(Batch);


                DialogResult result1 = MessageBox.Show("Data has been processed. Send hash total?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (result1 == DialogResult.No) Application.Exit();



                ReturnMe.SendHashTotal(Batch);

            }
        }



        private void TransferAll(string Batch)
        {
            if (Directory.Exists(Application.StartupPath + "\\Archive\\"+Batch) == false)
            {
                Directory.CreateDirectory(Application.StartupPath + "\\Archive\\" + Batch);
            }

            string[] files = Directory.GetFiles(Application.StartupPath + "\\Head\\", "*.txt");

            foreach (string file in files)
            {

                string filename = "";

                int LoopCount = file.Length - 1;
                while (LoopCount > 4)
                {
                    if (file.Substring(LoopCount, 1) == "\\")
                    {
                        if (filename == "")
                        {
                            filename = file.Substring(LoopCount + 1, file.Length - LoopCount - 1);
                        }
                    }

                    LoopCount = LoopCount - 1;
                }

                //lstFiles.Items.Add(filename);
                File.Copy(file, Application.StartupPath+"\\Archive\\"+Batch+"\\"+filename);
                File.Delete(file);
            }
        }



        private void DisplayData()
        {
            OleDbConnection conn1 = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Application.StartupPath + ";Extended Properties=dBASE III;");
            OleDbDataAdapter command1 = new OleDbDataAdapter("SELECT ChkType, FormType, SUM(OrderQty) FROM SBTC GROUP BY ChkType, FormType ORDER BY ChkType, FormType", conn1);
            conn1.Open();
            DataSet dataSet = new DataSet();
            command1.Fill(dataSet);

            string total = "";

            DataTable dt = dataSet.Tables[0];
            foreach (DataRow dr in dt.Rows)
            {
                string ChkType = dr[0].ToString();
                string FormType = dr[1].ToString();
                string OrderQty = dr[2].ToString();

                string chequename = ReturnMe.getChequeName(ChkType, FormType);

                if (total == "")
                {
                    total = chequename + ": " + OrderQty;
                }
                else
                {
                    total = total+"\r\n"+chequename + ": " + OrderQty;
                }
            }

            lblTotal.Text = total;
        }





        private void CheckBranches()
        { 
            OleDbConnection conn1 = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Application.StartupPath + ";Extended Properties=dBASE III;");
            OleDbDataAdapter command1 = new OleDbDataAdapter("SELECT DISTINCT(BRSTN) FROM SBTC", conn1);
            conn1.Open();
            DataSet dataSet = new DataSet();
            command1.Fill(dataSet);

            DataTable dt = dataSet.Tables[0];
            foreach (DataRow dr in dt.Rows)
            {
                string BRSTN = dr[0].ToString();



                OleDbDataAdapter command2 = new OleDbDataAdapter("SELECT Address1 , Address2 , Address3 , Address4 , Address5 , Address6 FROM Branches WHERE BRSTN = '"+BRSTN+"'", conn1);
                DataSet dataSet2 = new DataSet();
                command2.Fill(dataSet2);
                DataTable dt2 = dataSet2.Tables[0];

                if (dt2.Rows.Count == 1)
                {
                    foreach (DataRow dr2 in dt2.Rows)
                    {
                        string Address1 = dr2[0].ToString();
                        string Address2 = dr2[1].ToString();
                        string Address3 = dr2[2].ToString();
                        string Address4 = dr2[3].ToString();
                        string Address5 = dr2[4].ToString();
                        string Address6 = dr2[5].ToString();

                        string sql = "UPDATE SBTC SET Address1 = '" + Address1.Replace("'", "''") + "', Address2 = '" + Address2.Replace("'", "''") + "', Address3 = '" + Address3.Replace("'", "''") + "', Address4 = '" + Address4.Replace("'", "''") + "', Address5 = '" + Address5.Replace("'", "''") + "', Address6 = '" + Address6.Replace("'", "''") + "' WHERE BRSTN = '" + BRSTN + "'";
                        OleDbCommand command = new OleDbCommand(sql, conn1);
                        command.ExecuteReader();
                    }
                }
                else
                {
                    string sql = "INSERT INTO Errors (Errors) VALUES ('BRSTN "+BRSTN+" does not exists on Branches.dbf')";
                    OleDbCommand command = new OleDbCommand(sql, conn1);
                    command.ExecuteReader();
                }
            }
        }

        private void CreateTable()
        {
            if (System.IO.File.Exists("sbtc.dbf") == true)
            {
                System.IO.File.Delete("sbtc.dbf");
            }

            if (System.IO.File.Exists("temp.dbf") == true)
            {
                System.IO.File.Delete("temp.dbf");
            }

            if (System.IO.File.Exists("errors.dbf") == true)
            {
                System.IO.File.Delete("errors.dbf");
            }

            if (System.IO.File.Exists("batch.dbf") == true)
            {
                System.IO.File.Delete("batch.dbf");
            }

            string FilePath = Application.StartupPath;
            OleDbConnection conn = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + FilePath + ";Extended Properties=dBASE III;");

            OleDbCommand command = new OleDbCommand("CREATE TABLE SBTC (ChkType Varchar(6),BRSTN Varchar(9) , AccountNo Varchar(12), Name1 Varchar(60), Name2 Varchar(60), FormType Varchar(2),OrderQty Varchar(3), Batch Varchar(30), Address1 Varchar(60), Address2 Varchar(60), Address3 Varchar(60), Address4 Varchar(60), Address5 Varchar(60), Address6 Varchar(60), PKey Numeric, BStock Varchar(50), FileName Varchar(50), StartSN Varchar(50), PcsPerBook Varchar(3) , StartSN1 numeric)", conn);
            conn.Open();
            command.ExecuteReader();
            
            conn.Close();


            command = new OleDbCommand("CREATE TABLE Temp (AccountNo Varchar(12), AcctName Varchar(60), Batch Varchar(30), Pkey Numeric, FileName Varchar(50))", conn);
            conn.Open();
            command.ExecuteReader();

            conn.Close();


            command = new OleDbCommand("CREATE TABLE Errors (Errors Varchar(244))", conn);
            conn.Open();
            command.ExecuteReader();

            conn.Close();

            command = new OleDbCommand("CREATE TABLE Batch (Batch Varchar(244))", conn);
            conn.Open();
            command.ExecuteReader();

            conn.Close();
        }

        private void CheckFiles(string filename)
        {
            string Batch = filename.Substring(0, filename.Length - 4);


            var fileStream = new FileStream(Application.StartupPath + "\\Head\\" + filename, FileMode.Open, FileAccess.Read);
            using (var streamReader = new StreamReader(fileStream, Encoding.UTF8))
            {
                string line;
                while ((line = streamReader.ReadLine()) != null)
                {
                    pkey = pkey + 1;

                    string ChkType = line.Substring(0, 1).Trim();
                    string BRSTN = line.Substring(1, 9).Trim();
                    string AccountNo = line.Substring(11, 12).Trim();
                    string AccountName = line.Substring(23, 56).Trim();
                    AccountName = AccountName.Replace("Ñ", "N");
                    AccountName = AccountName.Replace("¥", "N");
                    AccountName = AccountName.Replace("NO NAME", "");
                    string ContCode = line.Substring(79, 1).Trim();
                    string FormType = line.Substring(80, 2).Trim();
                    string OrderQty = line.Substring(82, 2).Trim();

                    //YSECPT0408.txt --> YSE13Digit_cp0408.txt
                    //NOVABU0408.txt --> 13Digit_nb0408.txt
                    //CONSOL0408.txt --> 13Digit_cs0408.txt
                    //CAPTIV0408.txt --> 13Digit_cp0408.txt
                    //CPTIV0408.txt  --> 13Digit_cp0408.txt


                    //A     05      PA Reg
                    //B     16      CA Reg
    
                    //B     20      MC      --> mid(AccountNo,5,3) = "211" ---> MC (not 212)
                    //B     20      GC      --> mid(AccountNo,5,3) = "212" ---> GC

                    //YSECPT
                    //A     05      PA PreEncoded --> AA
                    //B     16      CA PreEncoded --> BB
    
                    
                    //F     25      PA CheckOne
                    //F     26      CA CheckOne
    
    
   
                    //E     23      PA CheckPower
                    //E     22      CA CheckPower
    
    


                    if ((ChkType == "A" && FormType == "05") || (ChkType == "B" && FormType == "16") || (ChkType == "F" && FormType == "25") || (ChkType == "F" && FormType == "26") || (ChkType == "B" && FormType == "20" && AccountNo.Substring(4, 3) != "212") || (ChkType == "B" && FormType == "20" && AccountNo.Substring(4, 3) == "212") || (ChkType == "E" && FormType == "22") || (ChkType == "E" && FormType == "23"))
                    {
                        if (filename.Substring(0, 6).ToUpper() == "YSECPT")
                        {
                            if (ChkType == "A" && FormType == "05") { ChkType = "AA"; }
                            if (ChkType == "B" && FormType == "16") { ChkType = "BB"; }
                        }

                        if 
                        (
                            (ChkType == "B" && FormType == "20" && AccountNo.Substring(4, 3) == "212") ||
                            (ChkType == "B" && FormType == "20" && AccountNo.Substring(0,1) == "9" && AccountNo.Substring(5, 7) == "2000022")
                        )
                        {
                            ChkType = "GC";
                            AccountName = "";
                        }

                        if (ChkType == "B" && FormType == "20" && AccountNo.Substring(4, 3) != "212") { ChkType = "MC"; }

                        int OrderQty2;
                        if( Int32.TryParse( OrderQty, out OrderQty2))
                        {
                        
                        }
                        else 
                        {
                            MessageBox.Show("Order Qty of Account Number " + AccountNo + " under file "+filename+" is invalid", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            Application.Exit();
                        }

                        if (ContCode == "" || ContCode == "1")
                        {
                            OleDbConnection conn = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Application.StartupPath + ";Extended Properties=dBASE III;");
                            OleDbCommand command = new OleDbCommand("INSERT INTO SBTC (BRSTN, ChkType, AccountNo , Name1 , FormType,OrderQty,Batch,Pkey,FileName) VALUES ('" + BRSTN + "','" + ChkType + "','" + AccountNo + "','" + AccountName.Replace("'", "''") + "','" + FormType + "','" + OrderQty2.ToString() + "','" + Batch + "'," + pkey + ",'" + filename + "')", conn);
                            conn.Open();
                            command.ExecuteReader();

                            conn.Close();
                        }

                        if (ContCode == "2")
                        {
                            OleDbConnection conn = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Application.StartupPath + ";Extended Properties=dBASE III;");
                            OleDbCommand command = new OleDbCommand("INSERT INTO Temp (AccountNo, AcctName,Batch,PKey, FileName) VALUES ('" + AccountNo + "','" + AccountName.Replace("'","''") + "','" + Batch + "'," + pkey + ",'" + filename + "')", conn);
                            conn.Open();
                            command.ExecuteReader();

                            conn.Close();
                        }

                    }

                    else 
                    {
                        MessageBox.Show("Unable to find the chequename of ChkType " + ChkType + " with FormType " + FormType + " on " + filename + ". Account No: " + AccountNo, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        Application.Exit();
                    }
                }
            }

            fileStream.Close();








            OleDbConnection conn1 = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Application.StartupPath + ";Extended Properties=dBASE III;");
            OleDbDataAdapter command1 = new OleDbDataAdapter("SELECT AccountNo, AcctName FROM Temp WHERE FileName = '" + filename + "' ORDER BY PKey", conn1);
            conn1.Open();
            DataSet dataSet = new DataSet();
            command1.Fill(dataSet);



            DataTable dt = dataSet.Tables[0];
            foreach (DataRow dr in dt.Rows)
            {


                string AccountNo = dr[0].ToString();
                string AcctName = dr[1].ToString();


                string sql = "SELECT PKey FROM SBTC WHERE FileName = '" + filename + "' AND AccountNo = '" + AccountNo + "' AND (Name2 IS NULL OR Name2 = '') ORDER BY PKey";
                command1 = new OleDbDataAdapter(sql, conn1);
                DataSet dataSet1 = new DataSet();
                command1.Fill(dataSet1);
                DataTable dt1 = dataSet1.Tables[0];




                Boolean already_updated = false;
                if (dt1.Rows.Count != 0)
                {
                    foreach (DataRow dr1 in dt1.Rows)
                    {
                        string primarykey = dr1[0].ToString();

                        if (already_updated == false)
                        {
                            OleDbConnection conn = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Application.StartupPath + ";Extended Properties=dBASE III;");
                            OleDbCommand command = new OleDbCommand("UPDATE SBTC SET Name2 = '" + AcctName.Replace("'", "''") + "' WHERE FileName = '" + filename + "' AND AccountNo = '" + AccountNo + "' AND PKey = " + primarykey, conn);
                            conn.Open();
                            command.ExecuteReader();

                            already_updated = true;
                        }
                    }
                }
                else
                {
                    MessageBox.Show(dt1.Rows.Count.ToString());
                    MessageBox.Show("Cont code of Account Number "+AccountNo+" is invalid", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    Application.Exit();
                }
            }

            conn1.Close();





        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            MessageBox.Show("A");

        }

        private void lblHashTotal_Click(object sender, EventArgs e)
        {

        }

        private void lblHashTotal_DoubleClick(object sender, EventArgs e)
        {
            this.Hide();

            frmHashTotal frmHashTotal = new frmHashTotal();
            frmHashTotal.ShowDialog();
            
            
            
        }
    }
}
